<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('portfolios') && !Schema::hasColumn('portfolios', 'link')) {
            Schema::table('portfolios', function (Blueprint $table) {
                $table->string("link")->nullable();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('portfolios') && Schema::hasColumn('portfolios', 'link')) {
            Schema::table('portfolios', function (Blueprint $table) {
                $table->dropColumn('link');
            });
        }
    }
};
