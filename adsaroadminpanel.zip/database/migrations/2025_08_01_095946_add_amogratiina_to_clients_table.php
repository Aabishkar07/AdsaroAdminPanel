<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('clients') && !Schema::hasColumn('clients', 'quotation_file')) {
            Schema::table('clients', function (Blueprint $table) {
                $table->string('quotation_file')->nullable()->after('reference_website');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('clients') && Schema::hasColumn('clients', 'quotation_file')) {
            Schema::table('clients', function (Blueprint $table) {
                $table->dropColumn('quotation_file');
            });
        }
    }
};
