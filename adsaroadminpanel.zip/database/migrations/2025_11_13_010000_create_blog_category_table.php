<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('blog_category')) {
            Schema::create('blog_category', function (Blueprint $table) {
                $table->unsignedBigInteger('blog_id');
                $table->unsignedBigInteger('category_id');
                $table->primary(['blog_id', 'category_id']);

                $table->foreign('blog_id')->references('id')->on('blogs')->onDelete('cascade');
                $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('blog_category');
    }
};
